/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sn.items.obsidian;

import net.minecraft.item.Item;
import net.minecraft.item.ItemHoe;

/**
 *
 * @author Stephanie
 */
public class OHoe extends ItemHoe
{
    public OHoe(Item.ToolMaterial mat){super(mat);}    
}