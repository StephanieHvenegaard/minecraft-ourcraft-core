/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sn.items.obsidian;

import net.minecraft.item.ItemAxe;

/**
 *
 * @author Stephanie
 */
public class OAxe extends ItemAxe
{
    public OAxe(ToolMaterial mat){super(mat);}    
}
