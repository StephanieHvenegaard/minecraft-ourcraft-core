/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sn.items.goldendiamond;

import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.item.ItemPickaxe;

/**
 *
 * @author Stephanie
 */
public class DGPickaxe extends ItemPickaxe{

    public DGPickaxe(ToolMaterial Mat) {
         super(Mat);
    }
}
